using System.ComponentModel.DataAnnotations;
using Fade_Lounge.Model;
using Fade_Lounge.ServicAs;
using Fade_Lounge.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Fade_Lounge.Pages.admin;


    public class EditKundeModel : PageModel
    {
        private IAdminRepository _repo;
        
        public EditKundeModel(IAdminRepository repo)
        {
            _repo = repo;
        }   
        [BindProperty]
        public int NytKundeNummer { get; set; }


        [BindProperty]
        [Required(ErrorMessage = "Der skal være et navn")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Der skal være mindst to tegn i et navn")]
        public string NytKundeNavn { get; set; }



        [BindProperty]
        [Required(ErrorMessage = "Der skal være et Nummer")]
        [StringLength(8, MinimumLength = 8, ErrorMessage = "Der skal være mindst otte tal i et nummer")]
        public string NytKundetlf { get; set; }
        
        [BindProperty]
        public string NyKundeEmail { get; set; }
        
        
        public string ErrorMessage { get; private set; }
        public bool Error { get; private set; }

        public void OnGet(int nummer)
        {
            ErrorMessage = "";
            Error = false;

            try
            {
                Admin admin = _repo.HentKunde(nummer);

                NytKundeNummer = admin.KundeNummer1;
                NytKundeNavn = admin.Navn1;
                NytKundetlf = admin.Tlf1;
                NyKundeEmail = admin.Email1;
            }
            catch (KeyNotFoundException knfe)
            {
                ErrorMessage = knfe.Message;
                Error = true;
            }
        }
        
        public IActionResult OnPost()
        {
            if ( !ModelState.IsValid )
            {
                return Page();
            }

            Admin admin = _repo.HentKunde(NytKundeNummer);
            admin.Navn1 = NytKundeNavn;
            admin.Tlf1 = NytKundetlf;
            admin.Email1 = NyKundeEmail;

            return RedirectToPage("Index");
        }



        public IActionResult OnPostCancel()
        {
            return RedirectToPage("Index");
        }
        
    }