using Fade_Lounge.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Fade_Lounge.Pages.Booking;

public class IndexModelP : PageModel
{
    // instance of burger repository
    private IBookingRepository _booking;

    // Dependency Injection
    public IndexModelP(IBookingRepository repository)
    {
        _booking = _booking;
    }

    // property for the View
    public List<Model.Booking> Bookings { get; set; }

    public void OnGet()
    {
        //BookingRepository repo = new BookingRepository(true);
        = _booking.h();
    }

    public IActionResult OnPost()
    {
        return RedirectToPage("NyBurger");
    }
}
