using Fade_Lounge.Model;
using Fade_Lounge.Services;
using Microsoft.Extensions.Primitives;

public class KundeRepository : IKundeRepository
{
    private List<Kunde?> _kunder = new List<Kunde?>();

    public Kunde? KundeLoggedIn { get; private set; }

    public KundeRepository(bool mockData = false)
    {
        if (mockData)
        {
            _kunder.Add(new Kunde(1, "saad", "42546563", "hsfh@live.dk", "2000", false));
            _kunder.Add(new Kunde(2, "saaad", "98234576", "yhbh@gmail.com", "2450", true));
            _kunder.Add(new Kunde(3, "ødelagt i fort 16-0", "12456587", "peop@outlook.gb", "4312", false));
        }
    }

    public void AddKunde(Kunde? kunde)
    {
        _kunder.Add(kunde);
    }

    public bool CheckKunde(string email, string adgangskode)
    {
        Kunde? foundUser = _kunder.Find(u => u.Email == email && u.Adgangskode == adgangskode);

        if (foundUser != null)
        {
            KundeLoggedIn = foundUser;
            return true;
        }
        else
        {
            return false;
        }
    }

    public void LogoutKunde()
    {
        KundeLoggedIn = null;
    }

    public Kunde? GetKundeByEmail(StringValues customerEmail)
    {
        return _kunder.FirstOrDefault(k => k.Email == customerEmail);    }
    

    public List<Kunde?> GetAlleKunder()
    {
        return _kunder;
    }

    public void RemoveKunde(Kunde? kunde)
    {
        _kunder.Remove(kunde);
    }
}