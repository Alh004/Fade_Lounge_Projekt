using Fade_Lounge.Model;
using Fade_Lounge.Pages.Booking;
using Fade_Lounge.ServicAs;

namespace Fade_Lounge.Services

{
    public class BookingRepository : IBookingRepository
    {

        // instans felt
        private Dictionary<string, Booking> _katalogBooking;

        private List<Booking> _bookings = new List<Booking>();



        // properties
        public Dictionary<string, Booking> Bkatalog
        {
            get { return _katalogBooking; }
            set { _katalogBooking = value; }
        }

        public BookingRepository(bool mockData = false)
        {
            _katalogBooking = new Dictionary<string, Booking>();

            if (mockData)
            {
                PopulateBookingRepository();
            }
        }

        private void PopulateBookingRepository()
        {
            _katalogBooking.Add(1.ToString(), new Booking("10:00", "Ali", "Taperfade", true, 300));
            _katalogBooking.Add(2.ToString(), new Booking("12:00", "Dani", "Lowfade", false, 250));
            _katalogBooking.Add(3.ToString(), new Booking("15:00", "Musti", "Midfade", true, 250));
        }


        public Dictionary<string, Booking> Bookings { get; set; }


        // Get all bookings
        public List<Booking> HentAlleBooking()
        {
            return _katalogBooking.Values.ToList();
        }

        // Get a specific booking by time
        public Booking HentBooking(string tid)
        {
            if (_katalogBooking.ContainsKey(tid))
            {
                return _katalogBooking[tid];
            }

            return null;
        }

        // Update a booking
        public Booking Opdater(Booking booking)
        {
            if (_katalogBooking.ContainsKey(booking.Tid))
            {
                _katalogBooking[booking.Tid] = booking;
                return booking;
            }

            return null;
        }

        // Delete a booking
        public Booking Slet(string tid)
        {
            if (_katalogBooking.ContainsKey(tid))
            {
                Booking deletedBooking = _katalogBooking[tid];
                _katalogBooking.Remove(tid);
                return deletedBooking;
            }

            return null;
        }

        public void Tilføj(Booking booking)
        {
            if (!_katalogBooking.ContainsKey(booking.Tid))
            {
                _katalogBooking.Add(booking.Tid, booking);
            }
        }
    }
}