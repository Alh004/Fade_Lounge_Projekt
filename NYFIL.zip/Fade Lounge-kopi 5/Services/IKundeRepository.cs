using Fade_Lounge.Model;
using Microsoft.Extensions.Primitives;

namespace Fade_Lounge.Services
{
    public interface IKundeRepository
    {
        Kunde? KundeLoggedIn { get; }
        
        void RemoveKunde(Kunde? kunde);
        
        void AddKunde(Kunde? kunde);
        
        bool CheckKunde(string email, string adgangskode);

        void LogoutKunde();
        Kunde? GetKundeByEmail(StringValues customerEmail);
    }
}