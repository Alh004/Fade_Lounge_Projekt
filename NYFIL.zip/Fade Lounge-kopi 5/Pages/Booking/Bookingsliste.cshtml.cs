using Microsoft.AspNetCore.Mvc.RazorPages;

using Fade_Lounge.Services;

namespace Fade_Lounge.Pages.Booking
{
    public class BookingListModel : PageModel
    {
        private readonly IBookingRepository _bookingRepository;

        public BookingListModel(IBookingRepository bookingRepository)
        {
            _bookingRepository = bookingRepository;
        }

        public List<Model.Booking> Bookings { get; set; }

        public void OnGet()
        {
            Bookings = _bookingRepository.HentAlleBooking();
        }
    }
}
