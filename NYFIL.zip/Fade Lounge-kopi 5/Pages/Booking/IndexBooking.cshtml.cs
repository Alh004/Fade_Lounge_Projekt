using Fade_Lounge.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Fade_Lounge.Pages.Booking
{
    public class IndexModelP : PageModel
    {
        private readonly IBookingRepository _bookingRepository;
        private readonly IKundeRepository _kundeRepository;

        public IndexModelP(IBookingRepository bookingRepository, IKundeRepository kundeRepository)
        {
            _bookingRepository = bookingRepository;
            _kundeRepository = kundeRepository;
        }

        [BindProperty] public string CustomerEmail { get; set; }

        public IActionResult OnPost()
        {
            // Retrieve customer by email
            var customer = _kundeRepository.GetKundeByEmail(CustomerEmail);

            if (customer == null)
            {
                ModelState.AddModelError("CustomerEmail", "Kunde ikke fundet.");
                return Page();
            }

            // Create a new booking
            var newBooking = new Model.Booking()
            {
                Tid = Request.Form["time"],
                Frisør = Request.Form["frisør"], // Add appropriate property for frisør
                Herreklip = Request.Form["herreklip"], // Assuming "herreklip" is the correct form field name
                Skæg = Request.Form["service"] == "2",
                Pris = Request.Form["service"] == "2" ? 300 : 250, // Set price based on service
                Kunde = customer // Assign the customer to the booking
            };

            // Add the booking to the repository
            _bookingRepository.Tilføj(newBooking);

            // Optionally, you can redirect to a confirmation page or another page
            return RedirectToPage("/BookingList");
        }
    }

}