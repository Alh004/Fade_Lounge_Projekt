using System.ComponentModel.DataAnnotations;
using Fade_Lounge.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Fade_Lounge.Pages.Booking;

public class NyOpretBookingModel : PageModel
{
    private IBookingRepository _repo;

    public NyOpretBookingModel(IBookingRepository repo)
    {
        _repo = repo;
    }

    [BindProperty] 
    public string NyTid { get; set; }

    [BindProperty]
    [Required(ErrorMessage = "Der skal være et navn")]
    [StringLength(100, MinimumLength = 2, ErrorMessage = "Der skal være mindst to tegn i et navn")]
    public string NyFrisør { get; set; }

    [BindProperty]
    [Required(ErrorMessage = "Der skal være et Nummer")]
    [StringLength(8, MinimumLength = 8, ErrorMessage = "Der skal være mindst otte tal i et nummer")]
    public string NyHerreKlip { get; set; }

    [BindProperty] public bool Nyskæg { get; set; }
        
    [BindProperty] public int Nypris { get; set; }

    public string ErrorMessage { get; private set; }

    public void OnGet()
    {
        // If you need to perform any actions when the page is loaded, you can include them here.
    }

    public IActionResult OnPost()
    {
        ErrorMessage = "";
        if (!ModelState.IsValid)
        {
            return Page();
        }

        Model.Booking nyBooking = new Model.Booking(NyTid, NyFrisør, NyHerreKlip, Nyskæg, Nypris);

        try
        {
            _repo.Tilføj(nyBooking);
        }
        catch (ArgumentException ae)
        {
            ErrorMessage = ae.Message;
            return Page();
        }

        return RedirectToPage("/Booking/BookingList\"");
    }

    public IActionResult OnPostCancel()
    {
        return RedirectToPage("/Booking/BookingList\"");
    }
}