using System.ComponentModel.DataAnnotations;
using Fade_Lounge.Model;
using Fade_Lounge.ServicAs;
using Fade_Lounge.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Fade_Lounge.Pages.admin;

public class OpretNyKundeAdmin : PageModel
{
    private IAdminRepository _repo;

    public OpretNyKundeAdmin (IAdminRepository repo)
    {
        _repo = repo;
    }

    [BindProperty]
    public string NytKundeNummer { get; set; }


    [BindProperty]
    [Required(ErrorMessage = "Der skal være et navn")]
    [StringLength(100, MinimumLength = 2, ErrorMessage = "Der skal være mindst to tegn i et navn")]
    public string NytKundeNavn { get; set; }



    [BindProperty]
    [Required(ErrorMessage = "Der skal være et Nummer")]
    [StringLength(8, MinimumLength = 8, ErrorMessage = "Der skal være mindst otte tal i et nummer")]
    public string NytKundetlf { get; set; }
        
    [BindProperty]
    public string NyKundeEmail { get; set; }
    
    [BindProperty]
    public bool NyKundeAdmin { get; set; }
    
       
        
        
    public string ErrorMessage { get; private set; }
    public bool Error { get; private set; }

public void OnGet()
{
    // If you need to perform any actions when the page is loaded, you can include them here.
}

public IActionResult OnPost()
{
    ErrorMessage = "";
    if (!ModelState.IsValid)
    {
        return Page();
    }

    Admin nyadmin = new Admin(NytKundeNummer, NytKundeNavn,NytKundetlf, NyKundeEmail,NyKundeAdmin );

    try
    {
        _repo.AddKundeAdm(nyadmin);
    }
    catch (ArgumentException ae)
    {
        ErrorMessage = ae.Message;
        return Page();
    }

    return RedirectToPage("Index");
}

public IActionResult OnPostCancel()
{
    return RedirectToPage("Index");
}
}
