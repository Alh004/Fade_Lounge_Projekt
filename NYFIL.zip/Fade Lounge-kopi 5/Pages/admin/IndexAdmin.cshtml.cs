using Fade_Lounge.Model;
using Fade_Lounge.ServicAs;
using Fade_Lounge.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Fade_Lounge.Pages.admin;

public class IndexxModel : PageModel

    {
        private IAdminRepository _admin;
        private readonly IAdminRepository _admins;

        public Admin AdminLoggedIn {  get; private set; }

        public IndexxModel(IAdminRepository admins)
        {
            _admins = admins;
        }

        public IActionResult OnGet()
        {
            if (_admin is null || _admins.AdminLoggedIn is null || !_admin.AdminLoggedIn.Isadmin1) {
                return RedirectToPage("/Login");
            }

            AdminLoggedIn = _admins.AdminLoggedIn;   

            return Page();
        }
    }



    