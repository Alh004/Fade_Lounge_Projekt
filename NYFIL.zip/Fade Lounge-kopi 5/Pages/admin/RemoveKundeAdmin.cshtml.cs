using Fade_Lounge.Model;
using Fade_Lounge.ServicAs;
using Fade_Lounge.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Fade_Lounge.Pages.admin;


public class RemoveKundeAdmin : PageModel
{
    private IAdminRepository _repo;
    
    public RemoveKundeAdmin(IAdminRepository repo)
    {
        _repo = repo;
    }



    public Admin Admin { get; private set; }
        

    public IActionResult OnGet(int kundeNummer)

    {
        Admin= _repo.RemoveKundeAdm(kundeNummer);


        return Page();
    }

    public IActionResult OnPostDelete(int kundeNummer)
    {
        _repo.RemoveKundeAdm(kundeNummer);

        return RedirectToPage("Index");
    }

    public IActionResult OnPostCancel()
    {
        return RedirectToPage("Index");
    }



}